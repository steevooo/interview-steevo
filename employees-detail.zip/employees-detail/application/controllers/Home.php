<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	function __construct()
	{
       parent::__construct();
       $this->load->model("Main","M");
       date_default_timezone_set("Asia/Kolkata");
	}

	public function index()
	{ 
		$data['emp'] = $this->M->getData("employee",null,null,null,array("empl_id" ,"desc"));
	    $this->load->view('employee',$data);
	  
	    
	    
	}
	function upload_excel()
	{
		$data = array();
		$filepath ='';
		$this->load->library('image_lib');
		if(!empty($_FILES['file']['name']))
		{ 
			$path = 'files/';
			$config['allowed_types'] = 'csv';
            $uploadPath = './'.$path;
	        if (!is_dir($uploadPath))
	        {
	            mkdir($uploadPath, 0755, TRUE);
	        }
			//$path = 'admin/uploads/'; 	
			$config['upload_path'] = $path;
		    $config['max_size'] = '5024000'; // max_size in kb 
		    $config['file_name'] = $_FILES['file']['name']; 

		    // Load upload library 
		    $this->load->library('upload',$config); 
		   // print_r($config);
		    // File upload
			    if($this->upload->do_upload('file'))
			    { 
			    	 $fileData = $this->upload->data();
			    	 //$this->resize_images($path,$fileData['file_name'],$rez_width,$rez_height);
						
                    $data = $this->uploadData($path,$fileData['file_name']);
                    if($data['res']==1)
                    {
                    	$info['emp'] = $this->M->getData("employee",null,null,null,array("empl_id" ,"desc"));
	    				$data['emptbl'] = $this->load->view('emptbl',$info,true);
                    }
			   		
			    }
			    else
			    { 
                    $data['res'] = '0';
			        $data['msg'] = $this->upload->display_errors(); 
			    } 
		   }else
		   { 
                $data['res'] = '0';
		        $data['msg'] = 'failed'; 
		   } 
		   echo json_encode($data);
	}
	public function uploadData($path,$import_xls_file)
	{
		           
			
			require_once APPPATH . "/third_party/PHPExcel/PHPExcel.php";
			
			$inputFileName = $path . $import_xls_file;
			try {
				$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
				$objReader = PHPExcel_IOFactory::createReader($inputFileType);
				$objPHPExcel = $objReader->load($inputFileName);
				$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
				$flag = true;
				$i=0;
				$p='';
				// print_r($allDataInSheet);exit;
				if(count($allDataInSheet)<=21)
				{
					for($kk=2;$kk<=count($allDataInSheet);$kk++) {
						if(empty($allDataInSheet[$kk]['A']))
						{
							$flag =false;
							$p="Employee Code required in row ".$kk.'</br>';
						}
						if(empty($allDataInSheet[$kk]['B']))
						{
							$flag =false;
							$p="Employee Name required in row".$kk.'</br>';
						}
						if(empty($allDataInSheet[$kk]['C']))
						{
							$flag =false;
							$p="Department required in row ".$kk.'</br>';
						}
						
						if(empty($allDataInSheet[$kk]['D']))
						{
							$flag =false;
							$p="Date of birth required in row ".$kk.'</br>';
						}
						else
						{
							if(!$this->validateDate(date('Y-m-d',strtotime($allDataInSheet[$kk]['D']))))
							{
								$flag =false;
								$p="Date of birth is invalid in row ".$kk.'</br>';
							}
						}
						if(empty($allDataInSheet[$kk]['E']))
						{
							$flag =false;
							$p="Date of join required in row ".$kk.'</br>';
						}
						else
						{
							if(!$this->validateDate(date('Y-m-d',strtotime($allDataInSheet[$kk]['E']))))
							{
								$flag =false;
								$p="Date of join is invalid in row ".$kk.'</br>';
							}
						}
					
					$inserdata[$i]['emp_code'] = $allDataInSheet[$kk]['A'];
					$inserdata[$i]['emp_name'] = $allDataInSheet[$kk]['B'];
					$inserdata[$i]['emp_dept'] = $allDataInSheet[$kk]['C'];
					
					$age = $this->dateDiff($allDataInSheet[$kk]['D']);
					$inserdata[$i]['emp_age'] = (int)$age;

					$exp = $this->dateDiff($allDataInSheet[$kk]['E']);
					$inserdata[$i]['emp_exp'] = $exp;

					$inserdata[$i]['emp_dob'] = date('Y-m-d',strtotime($allDataInSheet[$kk]['D']));
					$inserdata[$i]['emp_doj'] = date('Y-m-d',strtotime($allDataInSheet[$kk]['E']));

					$i++;
					}   
				}
				else
				{
					$flag =false;
					$p="Lines out of range !. Maximum of 20 lines is allowed";
				}            
				
				if($flag) 
				{
					$result = $this->M->batch_insert($inserdata,"employee");   
					if($result){
						 $data['res'] = '1';
			             $data['msg'] = 'Imported successfully'; 
					
					}else{
						$data['res'] = 'ERROR !';
			             $data['msg'] = 'Imported successfully'; 
					  
					} 
				} 
				else{
					$data['res'] = '0';
			        $data['msg'] = $p; 
				}  
				  

			} catch (Exception $e) {
				$data['res'] = '0';
			        $data['msg'] = $e->getMessage(); 
			   
			}
			return $data;
		}
	
	function dateDiff($d)
	{
		$d = date('Y-m-d',strtotime($d));
		$crnt_d = date('Y-m-d');

		$date1 = new DateTime($d);
		$date2 = new DateTime($crnt_d);
		$interval = $date2->diff($date1);
		//echo "difference " . $interval->y . " years, " . $interval->m." months, ".$interval->d." days "; 

		// shows the total amount of days (not divided into years, months and days like above)
		//echo "difference " . $interval->days . " days ";
		 return $interval->y.'.'.$interval->m;
		//return date_diff(date_create($d), date_create('today'))->y.'.'.date_diff(date_create($d), date_create('today'))->m;
	}
	function validateDate($date, $format = 'Y-m-d')
	{
		
	    $d = DateTime::createFromFormat($format, $date);
	    // The Y ( 4 digits year ) returns TRUE for any integer with any number of digits so changing the comparison from == to === fixes the issue.
	    return $d && $d->format($format) === $date;
	}
	
}
