    <?php
    class Main extends CI_Model
    {
    	
    	public function  getData($table='',$cond=NULL,$limit='0',$start='',$order=array('','asc'))
      {
        $this->db->select('*')->from($table)->order_by($order[0],$order[1]);
        if(!empty($limit))
          $this->db->limit($limit,$start);
        if(!empty($cond))
          $this->db->where($cond);
        $res=$this->db->get();

        if($res->num_rows()>0)
        {
          return $res->result();
        }
        return false;
      }
      
      public function batch_insert($data,$table)
      {
        return $this->db->insert_batch($table,$data);
      }
     

   

}

