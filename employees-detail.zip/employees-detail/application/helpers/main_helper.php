<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
{

  function p($abc)
  {
    echo "<pre>";
    print_r($abc);
    echo "</pre>";
  }

  function lq()
  {
  	$ff = & get_instance();
  	echo '<pre>';
  	echo $ff->db->last_query();
  	echo '</pre>';
  	exit;
  }
  
  function wordLimit($value,$count)
  { 
    $value=trim(strip_tags($value));
    return substr($value,0,$count);
  }
  
  function word($value,$count)
  {
    $ff = & get_instance();
    $ff->load->helper('text');
    $value=trim(strip_tags($value));
    return character_limiter($value, $count);
  }
  function word_html_strip($value,$count)
  {
    $ff = & get_instance();
    $ff->load->helper('text');
    
    return character_limiter($value, $count);
  }


  function current_url1()
  {
    return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
  }

  function dateConvert($originalDate)
  {
    return date("d-m-Y", strtotime($originalDate));
  }

  function dateWord($originalDate)
  {
    $a=explode('-', $originalDate);
    switch ($a[1])
    {
      case '1': $b="Jan"; break;
      case '2': $b="Feb"; break;
      case '3': $b="Mar"; break;
      case '4': $b="Apr"; break;
      case '5': $b="May"; break;
      case '6': $b="Jun"; break;
      case '7': $b="Jul"; break;
      case '8': $b="Aug"; break;
      case '9': $b="Sep"; break;
      case '10': $b="Oct"; break;
      case '11': $b="Nov"; break;
      case '12': $b="Dec"; break;
      default: $b=''; break;
    }
    return $a[0].' - '.$b.' - '.$a[2];
  }

  function dateWord1($originalDate)
  {
    $a=explode('/', $originalDate);
    switch ($a[1])
    {
      case '1': $b="Jan"; break;
      case '2': $b="Feb"; break;
      case '3': $b="Mar"; break;
      case '4': $b="Apr"; break;
      case '5': $b="May"; break;
      case '6': $b="Jun"; break;
      case '7': $b="Jul"; break;
      case '8': $b="Aug"; break;
      case '9': $b="Sep"; break;
      case '10': $b="Oct"; break;
      case '11': $b="Nov"; break;
      case '12': $b="Dec"; break;
      default: $b=''; break;
    }
    return $a[0].' - '.$b.' - '.$a[2];
  }

  function nocache()
  {
    header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
    header('Cache-Control: post-check=0, pre-check=0', FALSE);
    header('Pragma: no-cache');
    header('Expires: Wed, 05 Oct 1988 09:30:00 GMT');
    header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
  }

  function noHtml($str, $encoding='UTF-8')
  {
    $str=strip_tags($str);
    return (htmlspecialchars($str, ENT_QUOTES, $encoding));
  }

function b($a=null)
{
  if(!empty($a))
  {
    return base_url($a);
  }
  return base_url();
}
function todayDate()
{
  date_default_timezone_set('asia/kolkata');
  return $date = date('Y-m-d', time());
}

function currentTime()
{
    date_default_timezone_set('asia/kolkata');
    return $time = date('H:i');
}



}

