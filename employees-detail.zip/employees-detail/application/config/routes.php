<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Home';
$route['404_override'] = 'Login/error';
$route['505_override'] = 'Login/unothError';
$route['translate_uri_dashes'] = FALSE;

$route['employee'] = 'Home/index';
$route['upload-file'] = 'Home/upload_excel';
// //Ticket
// $route['create-ticket']  = 'Tickets/createTicket';
// $route['ticket-action'] = 'Tickets/ticketAction';
// $route['all-tickets'] = 'Tickets/allTickets';
// $route['ticket-assigned-list'] = 'Tickets/ticketAssignedList';
// $route['ticket-detail'] = 'Tickets/ticketDetail';
// $route['ticket-remove'] = 'Tickets/ticketRemove';
// $route['ticket-received-list'] = 'Tickets/ticketReceivedList';
// $route['ticket-status-select'] = 'Tickets/ticketStatusSelect';
// $route['ticket-status-select2'] = 'Tickets/ticketStatusSelect2';
// $route['ticket-status-change-action'] = 'Tickets/ticketStatusChangeAction';
// $route['ticket-status-change-action2'] = 'Tickets/ticketStatusChangeAction2';
// $route['ticket-update-change'] = 'Tickets/ticketUpdateChange';
// $route['notification-message'] = 'Dashboard/notificationMessage';
// $route['old-notifications'] = 'Dashboard/oldNotifications';

// //Attendance
// $route['attendance'] = 'Admin/Attendance_controller/attendance';
// $route['get-attendance'] = 'Admin/Attendance_controller/get_attendance';
// $route['edit-attendance'] = 'Admin/Attendance_controller/edit_attendance';
// $route['mark_attendance']='Admin/Attendance_controller/mark_attendance';
// $route['check_attendance'] = 'Admin/Attendance_controller/checkAttendance';
// $route['leave-details']='Dashboard/leave_details';

// //Saff
// $route['dashboard'] = 'Dashboard';

// //Login
// $route['login'] = 'Login';
// $route['login-action'] = 'Login/loginAction';
// $route['logout'] = 'Login/logout';

// //Report
// $route['work-report-add'] = 'Report';
// $route['report-action'] = 'Report/reportAction';
// $route['model-check'] = 'Report/modelCheck';
// $route['date-status'] = 'Report/dateStatus';
// $route['report-list'] = 'Report/reportList';
// $route['report-view'] = 'Report/reportView';

// //ADMIN
// $route['admin-list'] = 'Admin/Staffdetail_controller/adminList';
// $route['admin-detail-page'] = 'Admin/Staffdetail_controller/adminDetail';
// $route['add-admin'] = 'Admin/Staffdetail_controller/addAdmin';
// $route['add-admin/(:any)'] = 'Admin/Staffdetail_controller/addAdmin/$1';
// $route['submit-admin'] = 'Admin/Staffdetail_controller/submit_admin';
// $route['delete-admin'] = 'Admin/Staffdetail_controller/admin_delete';
// $route['admin-list-report'] = 'Admin/Actions';
// $route['admin-report-view'] = 'Admin/Actions/modelView';
// $route['admin-report-list-by-employee'] = 'Admin/Actions/employeeReport';
// $route['admin-report-list'] = 'Admin/Actions/employeeReportlist';
// $route['delete-report'] = 'Admin/Actions/deleteReport';
// $route['report-list-by-employee'] = 'Admin/Actions/employeeFilterReportList';
// $route['report-project-list'] = 'Admin/Actions/report_project_list';

// //Image
// $route['image']=  'Admin/Staffdetail_controller/image';

// //Projects
// $route['project-report-list'] = 'Admin/Projectdetail_controller/project_list';
// $route['project-report-list/(:any)'] = 'Admin/Projectdetail_controller/project_list/$1';
// $route['project-detail-list'] = 'Admin/Projectdetail_controller/project_detail_list';
// $route['add-project'] = 'Admin/Projectdetail_controller/add_project';
// $route['add-project/(:any)'] = 'Admin/Projectdetail_controller/add_project/$1';
// $route['submit-project'] = 'Admin/Projectdetail_controller/submit_project';
// $route['delete-project'] =  'Admin/Projectdetail_controller/project_delete';
// $route['project-file'] = 'Admin/Projectdetail_controller/project_file';
// $route['project-working-status'] = 'Admin/Projectdetail_controller/workingStatus';
// $route['client-project-list'] = 'Admin/Projectdetail_controller/client_project_list';
// $route['type-project-list'] = 'Admin/Projectdetail_controller/type_project_list';


// //Passsword-change
// $route['password-change'] = 'Login/passwordChange';
// $route['passchange-action'] = 'Login/passchangeAction';

// //Department Staff
// $route['list-dep-staff/(:num)'] = 'Admin/Department_controller/dep_staff_list/$1';
// $route['add-dep-staff/(:num)'] = 'Admin/Department_controller/addDepStaff/$1';
// $route['edit-dep-staff/(:any)'] = 'Admin/Department_controller/editDepStaff/$1';
// $route['submit-dep-staff'] = 'Admin/Department_controller/depStaffAction/$1';
// $route['dep-staff-detail-page'] = 'Admin/Department_controller/depStaffDetailPage';
// $route['delete-dep-staff'] = 'Admin/Department_controller/depStaffDelete';


// //Clients
// $route['delclient']='Admin/Client_controller/client_delete';
// $route['client'] = 'Admin/Client_controller/client';
// $route['addclient']='Admin/Client_controller/add_client';
// $route['addclient/(:any)'] = 'Admin/Client_controller/add_client/$1';
// $route['clientaction']='Admin/Client_controller/client_action';


// //Project type
// $route['project_type'] = 'Admin/Project_controller/projecttype';
// $route['addprojecttype']='Admin/Project_controller/add_projecttype';
// $route['addprojecttype/(:any)'] = 'Admin/Project_controller/add_projecttype/$1';
// $route['projecttypeaction']='Admin/Project_controller/projecttype_action';
// $route['delprojecttype']='Admin/Project_controller/projecttype_delete';

// //Chat
// $route['chat-home']='Admin/Chat_controller/chat_home';
// $route['chat_friend/(:num)']='Admin/Chat_controller/chat_friend/$1';
// $route['chat_action']='Admin/Chat_controller/chat_action';
// $route['chat_user']='Admin/Chat_controller/chat_user';
// $route['old-chats/(:num)']='Admin/Chat_controller/chat_friend/$1';
// $route['message-notify'] = 'Admin/Chat_controller/messageNotify';

// //chat group
// $route['group-chat']='Admin/Chat_controller/group_chat_home';
// $route['group_chat_user']='Admin/Chat_controller/group_chat_user';
// $route['group_chat_friend/(:num)']='Admin/Chat_controller/group_chat_friend/$1';
// $route['group_chat_action']='Admin/Chat_controller/group_chat_action';
// $route['old-group-chats/(:num)'] =  'Admin/Chat_controller/group_chat_friend/$1';
// $route['message-group-notify'] = 'Admin/Chat_controller/messageGroupNotify';


// //leave user
// $route['leave-application']='Leave_controller/leave_home';
// $route['submit-leave-form']='Leave_controller/submitleaveform';
// $route['leave-list-front']='Leave_controller/leave_list';
// $route['leave_list_front_action']='Leave_controller/leave_list_front_action';
// $route['get_front_leave'] = 'Leave_controller/get_leave';
// $route['get_Leave_Details'] = 'Leave_controller/get_leave_details';


// //leave admin
// $route['leave'] = 'Admin/Leave_controller/leave';
// $route['getleave'] = 'Admin/Leave_controller/get_leave';
// $route['acceptleave']='Admin/Leave_controller/leave_accept';
// $route['rejectleave']='Admin/Leave_controller/leave_reject';
// $route['getLeaveDetails'] = 'Admin/Leave_controller/get_leave_details';


// $route['group_chat_list']='Admin/Chatgroup_controller/chat_group';
// $route['add-group']='Admin/Chatgroup_controller/add_group';
// $route['submit-add-group']='Admin/Chatgroup_controller/submit_add_group';
// $route['delete-group']='Admin/Chatgroup_controller/delete_group';
// $route['edit-group/(:any)']='Admin/Chatgroup_controller/add_group/$1';
// $route['group-image']='Admin/Chatgroup_controller/group_image';







