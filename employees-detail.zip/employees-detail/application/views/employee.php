<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Employee Details</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  </head>
  <body>

    <div class="jumbotron text-center">
      <h1>Employee</h1>
    
    </div>
    
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <h3>Employee Details</h3>
        </div>
        <div class="col-sm-12">
          <p id="upmsg"></p>
        </div>
        <div class="col-sm-12" align="right">
          <button class="upbtn btn btn-info" onclick="clickUpload()"><i class="fa fa-upload"></i> Upload CSV</button></div>
          <input type="file" name="emp_upload" id="emp_upload"  style="opacity:0">
        </div>
        <div class="col-sm-12" id="empTbl">
          <?php $this->load->view('emptbl');?>
        </div>
      </div>
    </div>
    <input type="hidden" id="base" value="<?=base_url();?>">
    <script type="text/javascript">
      $(document).ready(function(){
        //image uploading function b
          $('#emp_upload').change(function () {
            
          $('.upbtn').html('<i class="fa fa-spin fa-spinner"></i>  Upload CSV');
              
                
          var base = $('#base').val();
          var file_data = $('#emp_upload').prop('files')[0];
          var form_data = new FormData();
          form_data.append('file', file_data);
        
          $.ajax({
            url : base+'upload-file',
            type: "POST",
            dataType:'json',
            data: form_data,
            contentType: false,  
            cache: false,
            processData: false,
            success: function (data) 
            {
              // console.log(data);       
              if(data.res==1)
              {
                $('#empTbl').html(data.emptbl);
                  $('#upmsg').html('<div class="alert alert-success" role="alert">'
                                    + data.msg
                                    +'</div>');
                
              }
              else
              {
                            
                $('#upmsg').html('<div class="alert alert-danger" role="alert">'
                                    + data.msg
                                    +'</div>')
              }
              $('#emp_upload').val('')
              $('.upbtn').html('<i class="fa fa-upload"></i> Upload CSV');
              
              
            }
          });
        });
      })
      function clickUpload()
        {
          $('#emp_upload').click();
        }
    </script>
  </body>
</html>