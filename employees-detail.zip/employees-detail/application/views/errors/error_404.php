<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
 <?php $this->load->view('inc/head'); ?>
</head>

<body class="menuclose menuclose-right">
<!-- Page Loader -->
<?php $this->load->view('inc/page-loader'); ?>
<!-- Page Loader Ends -->


<?php $this->load->view('inc/header'); ?>

<?php $this->load->view('inc/sidebar'); ?>

<div class="wrapper-content">
  <figure class="background"><img src="<?=img_path()?>error.png" alt=""></figure>
  <div class="container"> <br>
    <div class="row">
      <div class="col-lg-10 col-md-12 m-auto">
        <div class="row">
          <form class="form-signin1 light_bg text-center ">
            <br>
            <h3 class="display-2 text-warning"><strong>500</strong></h3>
            <h2 class="text-warning">Page not found</h2>
            <p class='text-white'>Sorry! There might be some internal error...</p>
            <p class='text-white'>Stay connected !</p>
          </form>
        </div>
      </div>
    </div>
  </div>
  <?php $this->load->view('inc/footer');  ?>
</div>

<?php $this->load->view('inc/scripts');  ?>
</body>
</html>