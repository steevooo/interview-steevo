<!DOCTYPE html>
<html lang="en">

<head>
 <?php $this->load->view('inc/head'); ?>
</head>
<body class="menuclose menuclose-right no-menu-show">

<?php $this->load->view('inc/page-loader'); ?>


<div class="wrapper-content">
  <figure class="background"><img src="<?=img_path()?>error.png" alt=""></figure>
  <div class="container"> <br>
    <div class="row">
      <div class="col-lg-10 col-md-12 m-auto">
        <div class="row">
          <form class="form-signin1 light_bg text-center ">
            <br>
            <h3 class="display-2 text-warning"><strong>500</strong></h3>
            <h2 class="text-warning">Unauthorized Access</h2>
            <div class="notes notes-danger" role="alert"> <strong>Oh snap!</strong> You are not allowed to access this page.... </div>
            <br>
            <br>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>



 
<?php $this->load->view('inc/scripts');  ?>
</body>


</html>