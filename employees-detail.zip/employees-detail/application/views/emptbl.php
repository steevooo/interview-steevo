<table class="table table-responsive">
  <thead>
    <tr>
      <th>No</th>
      <th>Employee Code</th>
      <th>Employee Name</th>
      <th>Department</th>
      <th>Age</th>
      <th>Experience in the Organization</th>
    </tr>
  </thead>
  <tbody>
<?php 
  if(!empty($emp))
  {
    foreach($emp as $index=>$e)
    {
?>
      <tr>
        <th><?=$index+1;?></th>
        <th><?=$e->emp_code;?></th>
        <th><?=$e->emp_name;?></th>
        <th><?=$e->emp_dept;?></th>
        <th><?=$e->emp_age;?></th>
        <th><?=$e->emp_exp;?></th>
      </tr>
<?php

    }
  }
  else
    {
?>
      <tr>
        <th colspan="5" align="center">No Data found</th>
    </tr>
<?php
    }
?>
  </tbody>
</table>